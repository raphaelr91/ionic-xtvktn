export const environment = {
  production: true,
  firebase : {
    apiKey: "AIzaSyBnvzds8l2R7fyj3ZBnpjDiW55euvpeVvg",
    authDomain: "ionicloja-b5739.firebaseapp.com",
    databaseURL: "https://ionicloja-b5739.firebaseio.com",
    projectId: "ionicloja-b5739",
    storageBucket: "ionicloja-b5739.appspot.com",
    messagingSenderId: "667756280123"
  }
};
